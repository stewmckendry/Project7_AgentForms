# server/app.py
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict

from src.models.assessment import analyze_freeform_input, finalize_draft_responses
from src.models.followup import generate_followup_question
from src.models.guidance import generate_guidance
from src.models.rtp_qa import generate_rtp_response_rule_based, generate_rtp_response_llm
from src.utils.io import load_yaml_cached

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load config and protocols once
assessment_questions = load_yaml_cached("data/protocols/concussion_assessment.yaml")
symptom_reference = load_yaml_cached("data/protocols/symptoms_reference.yaml")
rtp_reference = load_yaml_cached("data/protocols/return_to_play.yaml")

@app.get("/ping")
def ping():
    return {"status": "ok"}

class AnalyzeRequest(BaseModel):
    free_text: str

@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    result = analyze_freeform_input(req.free_text, assessment_questions)
    return result

class FinalizeRequest(BaseModel):
    draft_responses: Dict

@app.post("/finalize")
def finalize(req: FinalizeRequest):
    return finalize_draft_responses(req.draft_responses, assessment_questions)

class FollowupRequest(BaseModel):
    final_responses: Dict
    question_list: List[Dict]

@app.post("/followups")
def followups(req: FollowupRequest):
    followup_qs = [generate_followup_question(q["id"], req.final_responses[q["id"]], q, {}) for q in req.question_list if q["id"] in req.final_responses]
    return {"followups": [q["followup_question"] for q in followup_qs]}

class GuidanceRequest(BaseModel):
    assessment_bundle: Dict

@app.post("/guidance")
def guidance(req: GuidanceRequest):
    return generate_guidance(req.assessment_bundle)

class RTPRequest(BaseModel):
    activity_name: str
    assessment_bundle: Dict

@app.post("/rtp")
def rtp(req: RTPRequest):
    return generate_rtp_response_rule_based(req.activity_name, req.assessment_bundle, rtp_reference)

class RTPAskRequest(BaseModel):
    question: str
    assessment_bundle: Dict

@app.post("/rtp/ask")
def rtp_ask(req: RTPAskRequest):
    return generate_rtp_response_llm(req.question, req.assessment_bundle, rtp_reference)
