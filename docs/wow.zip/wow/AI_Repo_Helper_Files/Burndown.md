# 📉 Burndown – Feature Completion Status

_This file helps track open vs completed features over time._

## ✅ Delivered Features

- (auto-populated from patches in `.patches/`)

## 🔧 In Progress / Unstarted Features

- (to be maintained by human or delivery pod)

_This is a lightweight view — can be visualized later._

